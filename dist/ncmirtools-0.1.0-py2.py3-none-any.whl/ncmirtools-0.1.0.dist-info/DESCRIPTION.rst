===============================
ncmirtools
===============================



.. image:: https://pyup.io/repos/github/coleslaw481/ncmirtools/shield.svg
     :target: https://pyup.io/repos/github/coleslaw481/ncmirtools/
     :alt: Updates


Set of commandline too



Features
--------

* TODO

Credits
---------

This package was created with Cookiecutter_ and the `audreyr/cookiecutter-pypackage`_ project template.

.. _Cookiecutter: https://github.com/audreyr/cookiecutter
.. _`audreyr/cookiecutter-pypackage`: https://github.com/audreyr/cookiecutter-pypackage



=======
History
=======

0.1.0 (2016-09-30)
------------------

* First release on PyPI.


