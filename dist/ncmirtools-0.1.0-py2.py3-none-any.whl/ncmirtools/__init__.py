# -*- coding: utf-8 -*-

__author__ = 'Christopher Churas'
__email__ = 'churas.camera@gmail.com'
__version__ = '0.1.0'
