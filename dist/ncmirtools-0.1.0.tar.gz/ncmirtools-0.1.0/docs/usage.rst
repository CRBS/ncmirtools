=====
Usage
=====

To use ncmirtools in a project::

    import ncmirtools
